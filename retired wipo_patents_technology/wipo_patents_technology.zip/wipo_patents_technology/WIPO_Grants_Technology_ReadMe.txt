Intellectual property right :Patent							Indicator :5 - Patent grants by technology						Source: WIPO statistics database. Last updated: March 2015

Downloaded by: Paul Oldham
Date: 04/06/2015
URL: http://ipstats.wipo.int/ipstatv2/
See wipo_technology_search.png for search criteria 

Actions in Excel

1. Deleted top rows and moved text to this read me (above, top 3)
2. moved Office, Office(Code), Origin, Technology headers to top row, deleted blank row, removed bracket in column heading. To lower case and '_' for space
3. Filled blank spaces with NA with find and replace
4. Renamed then split technology_original into technology_number and technology. trimmed technology
5. Renamed worksheet to grants_tech
6. Renamed from "patent_5 - Patent grants by technology_Resident and non-resident count by filing office_1980_2013" to wipo_grants_technology.csv
7. Named raw file as raw_. Zipped archive. 

																																																																										