wipotrends is taken from the WIPO World Intellectual Property Indicators - 2014 Edition. Patent Data annex. Available from here. http://www.wipo.int/ipstats/en/wipi/

For R users a hint is to start reading from row 5. 

04.06/2015

Added cleaned as .csv file. Removed padding rows, inserted NA in blank cell